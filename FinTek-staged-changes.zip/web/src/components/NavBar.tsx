'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState, useRef, useEffect } from 'react';
import { useSession, signIn, signOut } from 'next-auth/react';
import { useTenant } from '@/lib/tenant-context';

const CHAT_STORAGE_KEY = 'munitor_chat_sessions';
const LEGACY_CHAT_STORAGE_KEY = 'munitor_chat_history';
const CHAT_RESET_EVENT = 'munitor:reset-chat';

const NAV_ITEMS = [
  { href: '/', label: 'Chat' },
  { href: '/upload', label: 'Upload' },
  { href: '/admin', label: 'Admin' },
];

export default function NavBar() {
  const pathname = usePathname();
  const { tenantId, setTenantId } = useTenant();
  const { data: session } = useSession();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const settingsInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (settingsOpen) settingsInputRef.current?.focus();
  }, [settingsOpen]);

  const handleBrandClick = () => {
    if (typeof window === 'undefined') return;
    localStorage.removeItem(CHAT_STORAGE_KEY);
    localStorage.removeItem(LEGACY_CHAT_STORAGE_KEY);
    window.dispatchEvent(new Event(CHAT_RESET_EVENT));
  };

  return (
    <nav className="sticky top-0 z-50 border-b border-white/10 bg-anchor-navy" role="navigation" aria-label="Main navigation">
      <div className="flex w-full items-center justify-between px-4 py-3 sm:px-6">
        {/* Brand */}
        <Link
          href="/"
          onClick={handleBrandClick}
          className="flex items-baseline gap-1.5 select-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-anchor-cyan rounded"
          aria-label="Fin-Tek Knowledge Base — Home"
        >
          <span className="text-white font-bold tracking-wide text-base">
            Fin-Tek
          </span>
          <span className="text-anchor-cyan font-semibold text-sm tracking-wide">
            Knowledge Base
          </span>
        </Link>

        {/* Desktop nav */}
        <div className="hidden sm:flex items-center gap-1" role="menubar">
          {NAV_ITEMS.map(({ href, label }) => {
            const active = pathname === href;
            return (
              <Link
                key={href}
                href={href}
                role="menuitem"
                aria-current={active ? 'page' : undefined}
                className={`rounded-md px-3 py-1.5 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-anchor-cyan ${
                  active
                    ? 'bg-white/10 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                {label}
              </Link>
            );
          })}

          {/* Tenant settings button */}
          <div className="relative ml-3">
            <button
              type="button"
              onClick={() => setSettingsOpen(!settingsOpen)}
              aria-expanded={settingsOpen}
              aria-haspopup="dialog"
              aria-label={tenantId ? `Tenant settings — ${tenantId.slice(0, 8)}…` : 'Set tenant ID'}
              className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-anchor-cyan ${
                tenantId
                  ? 'text-anchor-green hover:bg-white/5'
                  : 'text-amber-400 hover:bg-white/5'
              }`}
            >
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" d="M10.343 3.94c.09-.542.56-.94 1.11-.94h1.093c.55 0 1.02.398 1.11.94l.149.894c.07.424.384.764.78.93s.844.083 1.168-.166l.717-.537a1.125 1.125 0 0 1 1.6.18l.774.774a1.125 1.125 0 0 1 .18 1.6l-.537.717c-.249.324-.282.782-.166 1.168.116.396.456.71.88.78l.894.149c.542.09.94.56.94 1.11v1.093c0 .55-.398 1.02-.94 1.11l-.894.149c-.424.07-.764.384-.93.78s-.083.844.166 1.168l.537.717a1.125 1.125 0 0 1-.18 1.6l-.774.774a1.125 1.125 0 0 1-1.6.18l-.717-.537c-.324-.249-.782-.282-1.168-.166-.396.116-.71.456-.78.88l-.149.894c-.09.542-.56.94-1.11.94h-1.093c-.55 0-1.02-.398-1.11-.94l-.149-.894c-.07-.424-.384-.764-.78-.93s-.844-.083-1.168.166l-.717.537a1.125 1.125 0 0 1-1.6-.18l-.774-.774a1.125 1.125 0 0 1-.18-1.6l.537-.717c.249-.324.282-.782.166-1.168a1.125 1.125 0 0 0-.78-.88l-.894-.149c-.542-.09-.94-.56-.94-1.11v-1.093c0-.55.398-1.02.94-1.11l.894-.149c.424-.07.764-.384.93-.78s.083-.844-.166-1.168l-.537-.717a1.125 1.125 0 0 1 .18-1.6l.774-.774a1.125 1.125 0 0 1 1.6.18l.717.537c.324.249.782.282 1.168.166.396-.116.71-.456.78-.88l.149-.894Z" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
              </svg>
              {tenantId ? (
                <span className="hidden lg:inline text-xs text-gray-400 font-mono">
                  {tenantId.slice(0, 8)}…
                </span>
              ) : (
                <span className="text-xs">Set tenant</span>
              )}
            </button>

            {settingsOpen && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setSettingsOpen(false)} aria-hidden="true" />
                <div className="absolute right-0 z-50 mt-2 w-80 rounded-lg border border-white/10 bg-anchor-navy shadow-xl p-4" role="dialog" aria-label="Tenant settings">
                  <label htmlFor="tenant-id-input" className="block text-xs font-medium text-gray-400 mb-1.5">
                    Tenant ID
                  </label>
                  <input
                    id="tenant-id-input"
                    ref={settingsInputRef}
                    type="text"
                    value={tenantId}
                    onChange={(e) => setTenantId(e.target.value)}
                    placeholder="e.g. 00000000-0000-0000-0000-000000000001"
                    className="w-full rounded-md border border-white/10 bg-white/5 px-3 py-2 text-sm text-white placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-anchor-cyan/50"
                  />
                  <p className="mt-2 text-xs text-gray-500">
                    Required for API calls. Set via environment variable or enter manually.
                  </p>
                </div>
              </>
            )}
          </div>

          {/* Auth button */}
          <div className="ml-2">
            {session ? (
              <button
                type="button"
                onClick={() => signOut()}
                className="rounded-md px-3 py-1.5 text-sm font-medium text-gray-400 hover:text-white hover:bg-white/5 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-anchor-cyan"
              >
                Sign out
              </button>
            ) : (
              <button
                type="button"
                onClick={() => signIn('azure-ad')}
                className="rounded-md px-3 py-1.5 text-sm font-medium text-anchor-cyan hover:text-white hover:bg-white/5 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-anchor-cyan"
              >
                Sign in
              </button>
            )}
          </div>
        </div>

        {/* Mobile hamburger */}
        <button
          type="button"
          onClick={() => setMobileOpen(!mobileOpen)}
          className="sm:hidden rounded-md p-2 text-gray-400 hover:text-white hover:bg-white/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-anchor-cyan"
          aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
          aria-expanded={mobileOpen}
        >
          {mobileOpen ? (
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
            </svg>
          ) : (
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
            </svg>
          )}
        </button>
      </div>

      {/* Mobile menu panel */}
      {mobileOpen && (
        <div className="sm:hidden border-t border-white/10 px-4 pb-3 pt-2 space-y-1" role="menu">
          {NAV_ITEMS.map(({ href, label }) => {
            const active = pathname === href;
            return (
              <Link
                key={href}
                href={href}
                role="menuitem"
                aria-current={active ? 'page' : undefined}
                onClick={() => setMobileOpen(false)}
                className={`block rounded-md px-3 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-anchor-cyan ${
                  active
                    ? 'bg-white/10 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                {label}
              </Link>
            );
          })}
          <div className="border-t border-white/10 pt-3 mt-2">
            <label htmlFor="mobile-tenant-id" className="block text-xs font-medium text-gray-400 mb-1.5 px-3">
              Tenant ID
            </label>
            <input
              id="mobile-tenant-id"
              type="text"
              value={tenantId}
              onChange={(e) => setTenantId(e.target.value)}
              placeholder="Enter tenant UUID"
              className="mx-3 w-[calc(100%-1.5rem)] rounded-md border border-white/10 bg-white/5 px-3 py-2 text-sm text-white placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-anchor-cyan/50"
            />
          </div>
          {/* Mobile auth button */}
          <div className="border-t border-white/10 pt-3 mt-2 px-3">
            {session ? (
              <button
                type="button"
                onClick={() => signOut()}
                className="w-full rounded-md px-3 py-2 text-sm font-medium text-gray-400 hover:text-white hover:bg-white/5 transition-colors text-left"
              >
                Sign out
              </button>
            ) : (
              <button
                type="button"
                onClick={() => signIn('azure-ad')}
                className="w-full rounded-md px-3 py-2 text-sm font-medium text-anchor-cyan hover:text-white hover:bg-white/5 transition-colors text-left"
              >
                Sign in
              </button>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
